"""CarbonWise Allocator application package."""
